const express = require('express');
const bodyParser = require('body-parser');
const admin = require('firebase-admin');
const serviceAccount = require('C:\Users\Sanele TKZ\Desktop\CRUD\key');

admin.initializeApp({
    credential: admin.credential.cert(serviceAccount)
});
const db = admin.firestore();
const app = express();
app.use(bodyParser.json());

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});

// Create a new document
app.post('/create', async (req, res) => {
    try {
        const data = req.body;
        const docRef = await db.collection('items').add(data);
        res.status(201).send({ id: docRef.id });
    } catch (error) {
        res.status(500).send(error.message);
    }
});

// Read all documents
app.get('/read', async (req, res) => {
    try {
        const snapshot = await db.collection('items').get();
        const items = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        res.status(200).send(items);
    } catch (error) {
        res.status(500).send(error.message);
    }
});

// Update a document
app.put('/update/:id', async (req, res) => {
    try {
        const id = req.params.id;
        const data = req.body;
        await db.collection('items').doc(id).update(data);
        res.status(200).send('Document updated');
    } catch (error) {
        res.status(500).send(error.message);
    }
});

// Delete a document
app.delete('/delete/:id', async (req, res) => {
    try {
        const id = req.params.id;
        await db.collection('items').doc(id).delete();
        res.status(200).send('Document deleted');
    } catch (error) {
        res.status(500).send(error.message);
    }
});

